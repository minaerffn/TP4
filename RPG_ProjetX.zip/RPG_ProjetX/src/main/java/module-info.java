module com.example.rpg_projetx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.rpg_projetx to javafx.fxml;
    exports com.example.rpg_projetx;
}