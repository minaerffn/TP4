package com.example.rpg_projetx.raffin.utils;

public interface InputParser {
    public int promptWithIntParser(String prompt);
    public String prompt(String prompt);


}
