package com.example.rpg_projetx.raffin.rpg.items;

public class Armor extends Item{

    private int pvpoints;

    public Armor(String name) {
        super(name);
    }

    public int getPvpoints() {
        return pvpoints;
    }

    public void setPvpoints(int pvpoints) {
        this.pvpoints = pvpoints;
    }
}
