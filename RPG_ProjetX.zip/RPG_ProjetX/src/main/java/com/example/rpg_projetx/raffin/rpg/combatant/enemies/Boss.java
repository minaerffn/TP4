package com.example.rpg_projetx.raffin.rpg.combatant.enemies;

public class Boss extends Enemy{
    public Boss(int pv, int force) {
        super(pv, force);
    }

    @Override
    public String toString() {
        return "Boss (" + getPv() + " pv)";
    }
}
