package com.example.rpg_projetx.raffin.rpg.combatant;

public abstract class Combatant {
    private int pv;
    private int force;

    public Combatant(int pv, int force) {
        this.pv = pv;
        this.force = force;
    }

    public int getPv() {
        return pv;
    }

    public void setPv(int pv) {
        this.pv = pv;
    }

    public int getForce() {
        return force;
    }

    public void setForce(int force) {
        this.force = force;
    }

    public abstract int attack();

    public boolean isAlive() {
        return pv > 0;
    }

    public String increasePv() {
        this.pv += 10;
        System.out.println("Tu as plus de pv! Tu as maintenant " + this.pv + " de pv!");
        System.out.println();
        return "";
    }

    public String increaseForce() {
        this.force += 5;
        System.out.println("Tu as plus de forc! Tu as maintenant " + this.force + " de force!");
        System.out.println();
        return "";
    }
}
