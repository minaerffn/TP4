package com.example.rpg_projetx.raffin.rpg.exception;

public class InvalidPlayerClassException extends Exception {

    public InvalidPlayerClassException(String message) {
        super(message);
    }
}
