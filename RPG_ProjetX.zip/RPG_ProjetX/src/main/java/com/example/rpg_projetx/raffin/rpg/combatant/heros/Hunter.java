package com.example.rpg_projetx.raffin.rpg.combatant.heros;

import com.example.rpg_projetx.raffin.rpg.items.Item;

import java.util.List;
import java.util.UUID;

public class Hunter extends Hero {
    protected int arrows;

    public Hunter(int pv, int force, int armor, List<Item> backpack, int arrows) {
        super(pv, force, armor, backpack);
        this.arrows = arrows;
    }

    public Hunter(UUID id, int pv, int force, int armor, List<Item> backpack, int arrows) {
        super(id, pv, force, armor, backpack);
        this.arrows = arrows;
    }

    public String increaseArrows() {
        this.arrows += 3;
        System.out.println("Tu as plus de flèches! Tu as maintenant " + this.arrows + " flèches!");
        System.out.println();
        return "";
    }

    @Override
    public int attack() {
        if (arrows > 0) {
            arrows--;
            return getForce();
        }

        return 0;
    }

    @Override
    public String toString() {
        return "Hunter " ;
    }

    @Override
    public Hero duplicate() {
        return new Hunter(getId(), getPv(), getForce(), getArmor(), getBackpack(), arrows);
    }
}
