package com.example.rpg_projetx.raffin.rpg.combatant.enemies;

public class Gobelin extends Enemy {

    public Gobelin(int pv, int force) {
        super(pv, force);
    }

    @Override
    public String toString() {
        return "Gobelin (" + getPv() + " pv)";
    }
}
