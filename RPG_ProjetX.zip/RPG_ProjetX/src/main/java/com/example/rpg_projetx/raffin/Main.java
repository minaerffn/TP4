package com.example.rpg_projetx.raffin;

import com.example.rpg_projetx.raffin.rpg.Game;
import com.example.rpg_projetx.raffin.utils.ConsoleParser;

public class Main {
    public static void main(String[] args) {
        Game game = new Game(new ConsoleParser());
        System.out.println();
        game.play();
    }

}