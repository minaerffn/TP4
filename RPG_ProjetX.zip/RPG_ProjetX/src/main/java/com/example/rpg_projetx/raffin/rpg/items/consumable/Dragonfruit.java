package com.example.rpg_projetx.raffin.rpg.items.consumable;

public class Dragonfruit extends Consumable {

    public Dragonfruit(String name, int manapoints, int pvpoints) {
        super(name, manapoints, pvpoints);
    }

}
