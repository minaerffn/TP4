package com.example.rpg_projetx.raffin.rpg.combatant.enemies;

import com.example.rpg_projetx.raffin.rpg.combatant.Combatant;

public abstract class Enemy extends Combatant {

    public Enemy(int pv, int force) {
        super(pv, force);
    }

    @Override
    public int attack(){
        return getForce();
    }
}
