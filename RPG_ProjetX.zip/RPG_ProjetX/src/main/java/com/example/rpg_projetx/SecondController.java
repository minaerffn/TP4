package com.example.rpg_projetx;

import com.example.rpg_projetx.raffin.rpg.Game;
import com.example.rpg_projetx.raffin.utils.ConsoleParser;
import com.example.rpg_projetx.raffin.utils.GUIParser;
import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;

public class SecondController {

    @FXML
    void chargeGame(MouseEvent event) {
        Game game = new Game(new ConsoleParser());
        System.out.println();
        game.play();
    }
}
