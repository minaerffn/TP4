package com.example.rpg_projetx.raffin.rpg.combatant.heros;

import com.example.rpg_projetx.raffin.rpg.items.Item;
import com.example.rpg_projetx.raffin.rpg.items.consumable.Consumable;

import java.util.List;
import java.util.UUID;

public abstract class Spellcaster extends Hero {

    private int mana;
    private int manaCost;

    public Spellcaster(UUID id, int pv, int force, int armor, List<Item> backpack, int mana, int manaCost) {
        super(id, pv, force, armor, backpack);
        this.mana = mana;
        this.manaCost = manaCost;
    }

    public Spellcaster(int pv, int force, int armor, List<Item> backpack, int mana, int manaCost) {
        super(pv, force, armor, backpack);
        this.mana = mana;
        this.manaCost = manaCost;
    }

    public int getMana() {
        return mana;
    }

    public void setMana(int mana) {
        this.mana = mana;
    }

    public int getManaCost() {
        return manaCost;
    }

    public void setManaCost(int manaCost) {
        this.manaCost = manaCost;
    }

    @Override
    public int attack() {
        if (getMana() - getManaCost() >= 0) {
            return getForce();
        }
        return 0;
    }

    @Override
    public void consume(int index) {
        Consumable consumable = getConsumable().get(index);
        this.setPv(this.getPv() + consumable.getPvpoints());
        this.setMana(this.getMana() + consumable.getManapoints());
    }

    public abstract Hero duplicate();

    public String increaseMana() {
        this.mana += 3;
        System.out.println("Tu as plus de Mana! Tu as maintenant " + this.mana + " de mana!");
        System.out.println();
        return "";
    }
}
