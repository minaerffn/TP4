package com.example.rpg_projetx.raffin.utils;

public class GUIParser implements InputParser{
    @Override
    public int promptWithIntParser(String prompt) {
        return 1; // faut mettre ça??
    }

    @Override
    public String prompt(String prompt) {
        return null;
    }
}
