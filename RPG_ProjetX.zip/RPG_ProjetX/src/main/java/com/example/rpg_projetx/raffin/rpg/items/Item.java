package com.example.rpg_projetx.raffin.rpg.items;

public abstract class Item {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Item(String name) {
        this.name = name;
    }
}
