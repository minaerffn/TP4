package com.example.rpg_projetx.raffin.rpg.combatant.heros;

import com.example.rpg_projetx.raffin.rpg.items.Item;

import java.util.List;
import java.util.UUID;

public class Healer extends Spellcaster {

    public Healer(int pv, int force, int armor, List<Item> backpack, int mana, int manaCost) {
        super(pv, force, armor, backpack, mana, manaCost);
    }

    public Healer(UUID id, int pv, int force, int armor, List<Item> backpack, int mana, int manaCost) {
        super(id, pv, force, armor, backpack, mana, manaCost);
    }

    @Override
    public int attack() {
        if (getMana() - getManaCost() >= 0) {
            return getForce();
        }
        return 0;
    }

    @Override
    public String toString() {
        return "Healer ";
    }

    @Override
    public Hero duplicate() {
        return new Healer(getId(), getPv(), getForce(), getArmor(), getBackpack(), getMana(), getManaCost());
    }
}
