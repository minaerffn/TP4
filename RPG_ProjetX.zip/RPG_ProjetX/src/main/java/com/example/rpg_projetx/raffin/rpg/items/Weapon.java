package com.example.rpg_projetx.raffin.rpg.items;

public class Weapon extends Item{

    private int dammage;

    public int getDammage() {
        return dammage;
    }

    public void setDammage(int dammage) {
        this.dammage = dammage;
    }

    public Weapon(String name, int dammage) {
        super(name);
        this.dammage = dammage;
    }
}
