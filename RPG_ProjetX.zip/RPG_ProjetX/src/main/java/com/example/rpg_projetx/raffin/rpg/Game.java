package com.example.rpg_projetx.raffin.rpg;

import com.example.rpg_projetx.raffin.rpg.combatant.Combatant;
import com.example.rpg_projetx.raffin.rpg.combatant.enemies.*;
import com.example.rpg_projetx.raffin.rpg.combatant.heros.*;
import com.example.rpg_projetx.raffin.rpg.exception.InvalidPlayerClassException;
import com.example.rpg_projetx.raffin.rpg.items.consumable.Dragonfruit;
import com.example.rpg_projetx.raffin.rpg.items.consumable.Magicalpotion;
import com.example.rpg_projetx.raffin.utils.InputParser;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Game {

    private final InputParser inputParser;

    List<Hero> heroes = new ArrayList<>();

    public Game(InputParser inputParser) {
        this.inputParser = inputParser;
    }

    public void play() {
        createPlayers();

        for (int i = 1; i <= 5; i++) {
            System.out.println(">>>>> ROUND " + i + " <<<<<");
            List<Enemy> enemies = generateEnemies(i);
            List<Hero> duplicatedHeroes = new ArrayList<>();
            for(Hero hero : heroes) {
                duplicatedHeroes.add(hero.duplicate());
            }
            List<Combatant> fighters = new ArrayList<>();
            fighters.addAll(duplicatedHeroes);
            fighters.addAll(enemies);
            boolean roundWon = playRound(fighters);

            if (roundWon) {
                heroes.removeIf(hero -> !fighters.contains(hero));
                powerUps();
            } else {
                System.out.println("GAME OVER");
                break;
            }
        }
    }

    public void createPlayers() {
        int nbPlayers = inputParser.promptWithIntParser("\nAvec combien de joueurs voulez-vous jouer ?\n");
        if (0 < nbPlayers && nbPlayers < 11) {
            System.out.println();
            System.out.println("Voici la liste des classes possibles :");
            System.out.println("\033[1;32m"+"1- Hunter (70 pv 20 dégats)"+"\033[0m");
            System.out.println("\033[1;32m"+"2- Warrior (80 pv 15 dégats)"+"\033[0m");
            System.out.println("\033[1;32m"+"3- Mage (60 pv 13 dégats)"+"\033[0m");
            System.out.println("\033[1;32m" +"4- Healer (50 pv 10 dégats)"+"\033[0m");
            System.out.println();

            for (int i = 1; i <= nbPlayers; i++) {
                heroes.add(createHero(i));
            }

            System.out.println("Votre équipe est complète!\n");
        } else {
            System.out.println("Entrez un nombre de joueur entre 1 et 10");
            createPlayers();
        }

    }

    private Hero createHero(int playerIndex) {
        System.out.println("Création du héro pour le joueur " + playerIndex);
        int chosenClass = inputParser.promptWithIntParser("Choisissez la classe de votre héros en mettant son chiffre : ");
        try {
            return createHeroFromClassIndex(chosenClass);
        } catch (InvalidPlayerClassException e) {
            System.out.println("Ce chiffre ne correspond a aucune classe, recommencez");
            return createHero(playerIndex);
        }
    }

    public boolean playRound(List<Combatant> fighters) {
        while (atLeastOnePlayerAlive(fighters) && atLeastOneEnemyAlive(fighters)) {
            playerTurn(fighters);

            if (atLeastOneEnemyAlive(fighters)) {
                enemyTurn(fighters);
            }
        }

        if (atLeastOnePlayerAlive(fighters)) {
            System.out.println("Manche gagnée!!!\n");
            return true;
        } else {
            System.out.println("Manche perdue...\n");
            return false;
        }
    }

    private void playerTurn(List<Combatant> fighters) {
        Hero selectedHero = selectHero(fighters);
        int action = selectHeroAction();

        if (action == 1) {
            attackOrHeal(selectedHero, fighters);
        } else if (action == 2) {
            selectedHero.setDefending(true);
        } else if (action == 3) {
            useConsumable(selectedHero);
        }
    }

    private void useConsumable(Hero selectedHero) {
        if (selectedHero.getConsumable() == null || selectedHero.getConsumable().size() == 0) {
            System.out.println("Dommage, il n'y a rien dans le cartable du héros :\n");
            return;
        }

        System.out.println("Voici ce qu'il y a dans le cartable du héros :\n");
        for (int i = 0; i < selectedHero.getConsumable().size(); i++) {
            System.out.println(i + 1 + "- " + selectedHero.getBackpack().get(i).getName());
            System.out.println();
        }

        int consumable = inputParser.promptWithIntParser(("Quel objet utiliser ?\n"));

        if (consumable < 1 || consumable > selectedHero.getBackpack().size()) {
            useConsumable(selectedHero);
            System.out.println("Cet objet magique vous a permis d'augmenter vos capacités!" );
        }

        selectedHero.consume(consumable - 1);
    }

    private Hero selectHero(List<Combatant> fighters) {
        List<Hero> heroes = findHeroes(fighters);
        for (int i = 0; i < heroes.size(); i++) {
            int playerNumber = i + 1;
            Hero currentHero = heroes.get(i);

            if (currentHero.isAlive()) {
                System.out.printf("%s- %s(%s pv %s dégats)%n", playerNumber, currentHero, currentHero.getPv(), currentHero.getForce());
            }
        }

        int player = inputParser.promptWithIntParser(("Avec quel joueur voulez-vous jouer? "));
        return heroes.get(player - 1);
    }

    private int selectHeroAction() {
        System.out.println();
        System.out.println("Voici la liste des actions possible:");
        System.out.println();
        System.out.println("1- Attaquer / Soigner (healer)");
        System.out.println("2- Défendre");
        System.out.println("3- Consommer");
        System.out.println();

        return inputParser.promptWithIntParser(("Que voulez-vous faire?\n"));
    }

    private List<Hero> findHeroes(List<Combatant> fighters) {
        List<Hero> result = new ArrayList<>();
        for(Combatant combatant : fighters) {
            if (combatant instanceof Hero) {
                result.add((Hero) combatant);
            }
        }

        return result;
    }

    private List<Enemy> findEnemies(List<Combatant> fighters) {
        List<Enemy> result = new ArrayList<>();
        for(Combatant combatant : fighters) {
            if (combatant instanceof Enemy) {
                result.add((Enemy) combatant);
            }
        }

        return result;
    }

    private void attackOrHeal(Hero hero, List<Combatant> combatants) {
        if (hero.getClass() != Healer.class) {
            System.out.println("Voici la liste des ennemies: ");
            List<Enemy> enemies = findEnemies(combatants);
            for (int i = 0; i < enemies.size(); i++) {
                if (enemies.get(i).isAlive()) {
                    System.out.println(i + 1 + "- " + enemies.get(i).toString());
                }
            }

            int target = inputParser.promptWithIntParser(("Quel cible choisissez vous ?\n"));
            int targetIndex = target - 1;
            int damage = hero.attack() + hero.getWeapon();

            if (targetIndex < 0 || targetIndex >= enemies.size()) {
                attackOrHeal(hero, combatants);
            }

            enemies.get(targetIndex).setPv(enemies.get(target - 1).getPv() - damage);
            System.out.println("Bravo! Votre joueur a causé " + damage + " dégats au "+enemies.get(targetIndex).toString());
            System.out.println();

            if (!enemies.get(targetIndex).isAlive()) {
                System.out.println("Cet ennemi est mort!!\n");
                combatants.remove(enemies.get(targetIndex));
            }
        } else {
            System.out.println("Voici la liste des vos alliers:  ");
            List<Hero> heroes = findHeroes(combatants);
            for (int i = 0; i < heroes.size(); i++) {
                if (heroes.get(i).isAlive()) {
                    System.out.println(i + 1 + "- " + heroes.get(i) + heroes.get(i).getPv() + " pv");
                }
            }

            int target = inputParser.promptWithIntParser(("Quel cible choisissez vous ?\n"));
            heroes.get(target - 1).setPv(heroes.get(target - 1).getPv() + hero.attack());
            System.out.println("Vous avez soigné " + heroes.get(target -1) + "en lui ajoutant " + hero.attack() + " pv! Parfait pour repartir de plus belle!" );
            System.out.println();
        }
    }

    public List<Enemy> generateEnemies(int roundNumber) {
        List<Enemy> enemies = new ArrayList<>();
        int nbEnemies = heroes.size();
        for (int i = 0; i < nbEnemies; i++) {
            if (roundNumber == 1) {
                enemies.add(new Gobelin(20, 20));
            }
            else if (roundNumber == 2) {
                enemies.add(new Ogre(40, 40));
            }
            else if (roundNumber == 3) {
                enemies.add(new Chimera(60, 60));
            }
            else if (roundNumber == 4) {
                enemies.add(new Dragon(80, 80));
            }
            else {
                enemies.add(new Boss(100, 100));
            }
        }

        return enemies;
    }

    public boolean atLeastOnePlayerAlive(List<Combatant> combatants) {
        for (Combatant combatant : combatants) {
            if (combatant instanceof Hero && combatant.isAlive()) {
                return true;
            }
        }
        return false;
    }

    private boolean atLeastOneEnemyAlive(List<Combatant> combatants) {
        for (Combatant combatant : combatants) {
            if (combatant instanceof Enemy && combatant.isAlive()) {
                return true;
            }
        }
        return false;
    }

    public void enemyTurn(List<Combatant> fighters) {
        System.out.println("\nAu tour des ennemis d'attaquer !");
        List<Enemy> enemies = findEnemies(fighters);
        Enemy attackerEnemy = null;
        int i = 0;
        while (attackerEnemy == null) {
            if(enemies.get(i).isAlive()) {
                attackerEnemy = enemies.get(i);
            }
            i++;
        }
        Random rand = new Random();
        List<Hero> heroes = findHeroes(fighters);
        int attackedHeroIndex = rand.nextInt((heroes.size()));
        Hero attackedHero = heroes.get(attackedHeroIndex);
        if (aHeroIsDefending(heroes)) {
            System.out.println("Ne vous inquiettez pas! Vous avez maintenant tous une défense de " + attackedHero.getArmor() + " pv en plus!\n");
            attackedHero.setPv(attackedHero.getPv() + attackedHero.getArmor() - attackerEnemy.getForce());
            stopDefending(heroes);
        } else {
            attackedHero.setPv(attackedHero.getPv() - attackerEnemy.getForce());
        }

        if (!attackedHero.isAlive()) {
            System.out.println("Oh non ! " + attackedHero + " est mort\n");
            fighters.remove(attackedHero);
        } else {
            System.out.println("Aie aie! " +attackerEnemy +" a attaqué " + attackedHero);
            System.out.println(attackedHero + "n'a plus que " + attackedHero.getPv() + " pv\n");
        }
    }

    private boolean aHeroIsDefending(List<Hero> heroes) {
        for (Hero hero : heroes) {
            if (hero.isDefending()) {
                return true;
            }
        }

        return false;
    }

    private void stopDefending(List<Hero> heroes) {
        for (Hero hero : heroes) {
            hero.setDefending(false);
        }
    }

    public Hero createHeroFromClassIndex(int i) throws InvalidPlayerClassException {
        return switch (i) {
            case 1 -> new Hunter(70, 20, 10, List.of(new Dragonfruit("Fruit du dragon",0,4)), 10);
            case 2 -> new Warrior(80, 15, 10, List.of(new Dragonfruit("Fruit du dragon évolué", 0,6)));
            case 3 -> new Mage(60, 13, 5, List.of(new Magicalpotion("Potion magique", 4,0)), 20, 10);
            case 4 -> new Healer(50, 10, 5, List.of(new Magicalpotion("Potion magique évoluée", 6,0)), 20, 7);
            default -> throw new InvalidPlayerClassException("Invalid class index");
        };
    }

    private void powerUps() {
        for (Hero hero : heroes) {
            System.out.println("\nVous méritez d'augmenter vos capacités!!");
            System.out.println("Pour "+ hero+ " que voulez vous faire?");
            int chosenPowerUp = choosePowerUp();
            switch (chosenPowerUp) {
                case 1 -> hero.increaseArmor();
                case 2 -> hero.increaseWeaponDamage();
                case 3 -> hero.increaseConsumable();
                case 4 -> hero.increasePv();
                case 5 -> ((Spellcaster) hero).increaseMana();
                case 6 -> ((Hunter) hero).increaseArrows();
                case 7 -> hero.increaseForce();
            }
        }
        System.out.println("\nEt voila! Belle évolution! On se retrouve à la prochaine étape!\n");
    }

    private int choosePowerUp() {
        System.out.println("Choississez une option :\n");
        System.out.println("1- Augmenter la résistance de l'armure");
        System.out.println("2- Augmenter les dégats des armes");
        System.out.println("3- Augmenter les effets des fruits et potions magique");
        System.out.println("4- Augmenter le nombre de pv");
        System.out.println("5- Augmenter le nombre de mana (Healer et Mage)");
        System.out.println("6- Augmenter le nombre de flèches (Hunter)");
        System.out.println("7- Augmenter les dégats");

        System.out.println();

        int result = inputParser.promptWithIntParser(("Quel option souhaitez-vous ?\n"));

        if (result < 1 || result > 7) {
            choosePowerUp();
        }

        return result;
    }
}


