package com.example.rpg_projetx.raffin.rpg.items.consumable;

public class Magicalpotion extends Consumable{

    public Magicalpotion(String name, int manapoints, int pvpoints) {
        super(name, manapoints, pvpoints);
    }
}
