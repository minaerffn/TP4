package com.example.rpg_projetx.raffin.rpg.combatant.heros;

import com.example.rpg_projetx.raffin.rpg.items.Item;

import java.util.List;
import java.util.UUID;

public class Mage extends Spellcaster {

    public Mage(int pv, int force, int armor, List<Item> backpack, int mana, int manaCost) {
        super(pv, force, armor, backpack, mana, manaCost);
    }

    public Mage(UUID id, int pv, int force, int armor, List<Item> backpack, int mana, int manaCost) {
        super(id, pv, force, armor, backpack, mana, manaCost);
    }

    @Override
    public String toString() {
        return "Mage ";
    }

    @Override
    public Hero duplicate() {
        return new Mage(getId(), getPv(), getForce(), getArmor(), getBackpack(), getMana(), getManaCost());
    }
}