package com.example.rpg_projetx.raffin.rpg.combatant.heros;

import com.example.rpg_projetx.raffin.rpg.combatant.Combatant;
import com.example.rpg_projetx.raffin.rpg.items.Item;
import com.example.rpg_projetx.raffin.rpg.items.consumable.Consumable;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public abstract class Hero extends Combatant {

    private final UUID uniqueIdentifier;
    private int armor;
    private int weapon;
    private boolean isDefending;
    private List<Item> backpack;

    protected Hero(UUID uniqueIdentifier, int pv, int force, int armor, List<Item> backpack) {
        super(pv, force);
        this.uniqueIdentifier = uniqueIdentifier;
        this.armor = armor;
        this.backpack = backpack != null ? backpack : new ArrayList<>();
    }

    public Hero(int pv, int force, int armor, List<Item> backpack) {
        super(pv, force);
        this.uniqueIdentifier = UUID.randomUUID();
        this.armor = armor;
        this.backpack = backpack != null ? backpack : new ArrayList<>();
    }

    public UUID getId() { return uniqueIdentifier; }

    public int getWeapon() {return weapon;}

    public void setWeapon(int weapon) {this.weapon = weapon;
    }

    public int getArmor() {
        return armor;
    }

    public void setArmor(int armor) {
        this.armor = armor;
    }

    public boolean isDefending() {
        return isDefending;
    }

    public void setDefending(boolean defending) {
        isDefending = defending;
    }

    public List<Item> getBackpack() {
        return backpack;
    }

    public void setBackpack(List<Item> backpack) {
        this.backpack = backpack;
    }

    public List<Consumable> getConsumable() {
        List<Consumable> result = new ArrayList<>();
        for (Item item : getBackpack()) {
            if (item instanceof Consumable) {
                result.add((Consumable) item);
            }
        }
        return result;
    }

    public void consume(int index) {
        Consumable consumable = getConsumable().get(index);
        this.setPv(this.getPv() + consumable.getPvpoints());
        System.out.println("Pour " + index + " :");
    }

    public String increaseArmor() {
        this.armor += 3;
        System.out.println("Ton armure est plus solide! Tu as une armur maintenant de " + this.armor + " pv de protection!");
        System.out.println();
        return "";
    }

    public String increaseWeaponDamage() {
        this.weapon += 3;
        System.out.println("Tes armes fonts plus de dégats! Tu as maintenant " + this.weapon + " de dégats pour tes armes!");
        System.out.println();
        return "";
    }

    public String increaseConsumable() {
        String consumable = null;
        for (int i = 0; i < backpack.size(); i++) {
            consumable = backpack.get(0).getName();
        }
        System.out.println("Tes potions et tes fruits font plus d'effet! Tu as maintenant " + consumable + " qui te rendra plus fort!");
        System.out.println();
        return "";
    }

    public abstract Hero duplicate();

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Hero) {
            return this.getId() == ((Hero) obj).getId();
        }

        return false;
    }

}
