package com.example.rpg_projetx.raffin.rpg.items.consumable;

import com.example.rpg_projetx.raffin.rpg.items.Item;

public abstract class Consumable extends Item {
    private int pvpoints;
    private int manapoints;

    public Consumable(String name, int manapoints, int pvpoints){
        super(name);
        this.manapoints = manapoints;
        this.pvpoints = pvpoints;
    }

    public int getPvpoints() {
        return pvpoints;
    }

    public void setPvpoints(int pvpoints) {
        this.pvpoints = pvpoints;
    }

    public int getManapoints() {
        return manapoints;
    }

    public void setManapoints(int manapoints) {
        this.manapoints = manapoints;
    }

}
