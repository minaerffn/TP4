package com.example.rpg_projetx.raffin.rpg.combatant.heros;

import com.example.rpg_projetx.raffin.rpg.items.Item;

import java.util.List;
import java.util.UUID;

public class Warrior extends Hero {

    public Warrior(int pv, int force, int armor, List<Item> backpack) {
        super(pv, force, armor, backpack);
    }

    public Warrior(UUID id, int pv, int force, int armor, List<Item> backpack) {
        super(id, pv, force, armor, backpack);
    }

    @Override
    public int attack() {
        return getForce();
    }

    @Override
    public String toString() {
        return "Warrior " ;
    }

    @Override
    public Hero duplicate() {
        return new Warrior(getId(), getPv(), getForce(), getArmor(), getBackpack());
    }
}
