package com.example.rpg_projetx.raffin.rpg;

import com.example.rpg_projetx.raffin.utils.InputParser;

public class TestInputParser implements InputParser {

    @Override
    public int promptWithIntParser(String prompt) {
        return 1;
    }

    @Override
    public String prompt(String prompt) {
        return null;
    }
}
