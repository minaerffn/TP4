package com.example.rpg_projetx.raffin.rpg.combatant.heros;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class HunterTest {

    private Hunter hunter;

    @BeforeEach
    public void setup() {
        hunter = new Hunter(10, 6, 7, new ArrayList<>(), 1);
    }

    @Test
    public void testGetPv() {
        Assertions.assertEquals(10, hunter.getPv());
    }

    @Test
    public void testGetForce() {
        Assertions.assertEquals(6, hunter.getForce());
    }

    @Test
    public void testGetArmor() {
        Assertions.assertEquals(7, hunter.getArmor());
    }

    @Test
    public void testGetConsumable() {
        Assertions.assertEquals(0, hunter.getConsumable().size());
    }

    @Test
    public void testGetArrows() {
        Assertions.assertEquals(1, hunter.arrows);
    }

    @Test
    public void testAttackLowerArrow() {
        hunter.attack();
        Assertions.assertEquals(0, hunter.arrows);
    }

    @Test
    public void testAttack() {
        Assertions.assertEquals(hunter.getForce(), hunter.attack());
    }

    @Test
    public void testNoAttackWithoutArrow() {
        hunter.attack();
        Assertions.assertEquals(0, hunter.attack());
    }

    @Test
    public void testToString() {
        Assertions.assertEquals("Hunter ", hunter.toString());
    }
}