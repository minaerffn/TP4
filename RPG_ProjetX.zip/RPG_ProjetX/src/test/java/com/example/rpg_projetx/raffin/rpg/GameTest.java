package com.example.rpg_projetx.raffin.rpg;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GameTest {

    private Game game = new Game(new TestInputParser());

    @Test
    public void shouldPlayWithoutError() {
        game.play();
        Assertions.assertTrue(true); // ça a pas planté
    }
}