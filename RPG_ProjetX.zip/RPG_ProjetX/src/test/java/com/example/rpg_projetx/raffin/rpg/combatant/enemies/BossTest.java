package com.example.rpg_projetx.raffin.rpg.combatant.enemies;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class BossTest {

    @Test
    public void testToString() {
        Boss boss = new Boss(5, 5);

        Assertions.assertEquals("Boss (5 pv)", boss.toString());
    }
}